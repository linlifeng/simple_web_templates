#!/usr/bin/python

'''
input format:
    layer (integer, from 100 to 10)     tag(for navgation)  content words

<p class="bookmark" id="layer100tag" onclick="scrollto('0')">Layer 100</p>

<div class="blackPane page" id="layer100">
    <div class="contentbox">
        <h1>This is the Top Layer</h1>
        <p>This is the content of the top layer.</p>
    </div>
</div>
'''


from sys import argv
from os import system

fname = argv[1]
f = open(fname,'r')

# load headers and css
print "<html><head>    <script src=\"//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\"></script>        <link href='http://fonts.googleapis.com/css?family=Swanky+and+Moo+Moo|Meie+Script|Indie+Flower' rel='stylesheet' type='text/css'><style>/* overall framework*/body {height: 1000%;}.page { position: fixed; top: 0px; left: 0px; width: 100%; height: 100%; -webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover; background-size: cover; font-family: 'Swanky and Moo Moo', cursive; color: grey; box-shadow: 0px 8px 20px #666; }.contentbox { width: 61.8%; height: 70%; margin: 10% auto; overflow: auto; }    .contentbox p {display: block; font-size: 1.5vw}    .contentbox h1 {}.twoCol img { float: left; width: 50%; }.twoCol p { float: left; width: 50%; }.bookmark { color: grey; position: fixed; right: 0px; cursor: pointer; font-size: 18px; font-family: 'Swanky and Moo Moo', cursive; z-index: 110; }.bookmark:hover { cursor: pointer; text-shadow: 5px 5px 10px #666; -webkit-transform: scale(1.2); }/*background classes*/.blackPane {background: black;}.whitePane {background: white;}.silverPane {background: silver;}/*layers*/#layer100 {z-index: 100;}#layer90 {z-index: 90;}#layer80 {z-index: 80;}#layer70 {z-index: 70;}#layer60 {z-index: 60;}#layer50 {z-index: 50;}#layer40 {z-index: 40;}#layer30 {z-index: 30;}#layer20 {z-index: 20;}#layer10 {z-index: 10;}/*tags for each section*/#layer100tag {top: 0%;}#layer90tag {top: 10%;}#layer80tag {top: 20%;}#layer70tag {top: 30%;}#layer60tag {top: 40%;}#layer50tag {top: 50%;}#layer40tag {top: 60%;}#layer30tag {top: 70%;}#layer20tag {top: 80%;}#layer10tag {top: 90%;}</style></head><body>"

for l in f:
    imgsrc = ''
    segs = l.rstrip().split('\t')
    ## layouts
    layout = "oneCol"
    layer, tag, content = segs[:3]
    if len(segs) > 3:
        imgsrc = segs[3]
    if len(content) > 1 and len(segs) > 3:
        layout = "twoCol"
    ###

    ## background colors for covers
    if layer == str(100):
        pageType = "blackPane"
    elif layer == str(10):
        pageType = "silverPane"
    else:
        pageType = "whitePane"
    ###


    print "<p class=\"bookmark\" id=\"layer%stag\" onclick=\"scrollto('%s')\">%s</p>"%(layer, (100-int(layer))/100.00, tag)
    print "<div class=\"%s page\" id=\"layer%s\" style=\'background-image: url(\"%s\"); background-size: cover\'>"%(pageType, layer, imgsrc)
    print "<div class=\"contentbox %s\">"%layout
    print "<p>" + content + "</p>"
    print "</div></div>"

print "</body>"
print "<script>"
#functions for page fliping
print "$(window).scroll(function() {        var toppos=jQuery(window).scrollTop();        var scrollHeight = jQuery(window).height();        var topperc=(toppos/(scrollHeight));        jQuery('.bookmark').css('fontSize',18);        jQuery('#layer100tag').css('fontSize',25);        if(topperc > 0.0 ){                jQuery('#layer100').css('top',-topperc*1000+'%');                jQuery('.bookmark').css('fontSize',18);                jQuery('#layer90tag').css('fontSize',25);        }        else{                jQuery('#layer100').css('top','0%');        $(\".bookmark\").fadeIn('slow');        }        if(topperc > 0.1 ){                jQuery('#layer90').css('top',100-topperc*1000+'%');                jQuery('.bookmark').css('fontSize',18);                jQuery('#layer80tag').css('fontSize',25);        }        else{                jQuery('#layer90').css('top','0%');        }        if(topperc > 0.2){                jQuery('#layer80').css('top',200-topperc*1000+'%');                jQuery('.bookmark').css('fontSize',18);                jQuery('#layer70tag').css('fontSize',25);        }        else{                jQuery('#layer80').css('top','0px');        }if(topperc > 0.3){                jQuery('#layer70').css('top',300-topperc*1000+'%');                jQuery('.bookmark').css('fontSize',18);                jQuery('#layer60tag').css('fontSize',25);        }        else{                jQuery('#layer70').css('top','0px');        }        if(topperc > 0.4){                jQuery('#layer60').css('top',400-topperc*1000+'%');                jQuery('.bookmark').css('fontSize',18);                jQuery('#layer50tag').css('fontSize',25);        }        else{                jQuery('#layer60').css('top','0px');        }        if(topperc > 0.5){                jQuery('#layer50').css('top',500-topperc*1000+'%');                jQuery('.bookmark').css('fontSize',18);                jQuery('#layer40tag').css('fontSize',25);        }        else{                jQuery('#layer50').css('top','0px');        }        if(topperc > 0.6){                jQuery('#layer40').css('top',600-topperc*1000+'%');                jQuery('.bookmark').css('fontSize',18);                jQuery('#layer30tag').css('fontSize',25);        }        else{                jQuery('#layer40').css('top','0px');        }        if(topperc > 0.7){                jQuery('#layer30').css('top',700-topperc*1000+'%');                jQuery('.bookmark').css('fontSize',18);                jQuery('#layer20tag').css('fontSize',25);        }        else{                jQuery('#layer30').css('top','0px');        }        if(topperc > 0.8){                jQuery('#layer20').css('top',800-topperc*1000+'%');                jQuery('.bookmark').css('fontSize',18);                jQuery('#layer10tag').css('fontSize',25);        }        else{                jQuery('#layer20').css('top','0px');        }});"

#function scroll to
print " function scrollto(topperc){        var Height = jQuery(window).height();        var ypos=topperc*Height;        $(\"html, body\").animate({ scrollTop: ypos}, 500);    }"
#hiding sidebar
print "$( \"body\" ).mousemove(function( event ) {        var Width = jQuery(window).width();            var hotLine = 0.9;        cursorXperc = event.pageX/Width;        if(cursorXperc > hotLine){            $(\".bookmark\").fadeIn();        }        else{            $(\".bookmark\").fadeOut();        }});"

print"</script>"
print "</html>"



